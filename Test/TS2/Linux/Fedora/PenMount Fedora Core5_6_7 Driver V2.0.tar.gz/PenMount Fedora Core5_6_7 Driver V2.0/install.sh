#!/bin/bash

cp -f xdrv-adv/penmount_drv.so /usr/lib/xorg/modules/input

cp -f pm-setup /usr/sbin
cp -f pm-setup.sh /etc/rc.d/init.d
ln -s /etc/rc.d/init.d/pm-setup.sh /etc/rc.d/rc5.d/S08pm-setup

/usr/sbin/pm-setup

