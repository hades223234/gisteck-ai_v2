#!/bin/bash

sudo -u root mkdir /usr/share/penmount
sudo -u root chown -R root.root *

sudo -u root cp -f icon/penmount.png     /usr/share/penmount
sudo -u root cp -f icon/penmount0.gif    /usr/share/penmount
sudo -u root cp -f icon/penmount4.gif    /usr/share/penmount
sudo -u root cp -f icon/penmount9.gif    /usr/share/penmount
sudo -u root cp -f icon/penmount16.gif   /usr/share/penmount
sudo -u root cp -f icon/penmount25.gif   /usr/share/penmount

sudo -u root cp -f pm-calib-sel.tcl /usr/share/penmount
sudo -u root cp -f penmount.desktop /usr/share/applications
sudo -u root cp -f pm-setup         /usr/sbin
sudo -u root cp -f pm-setup.sh      /etc/init.d
sudo -u root cp -f penmount.dat     /etc
sudo -u root cp -f pm-calib         /usr/sbin
sudo -u root cp -f pm-sniff         /usr/sbin
sudo -u root cp -f pm-sniff-usb     /usr/sbin
sudo -u root cp -f pm-report        /usr/share/penmount
sudo -u root cp -f README-ubuntu    /usr/share/penmount

sudo -u root ln -s /etc/init.d/pm-setup.sh /etc/rc2.d/S08pm-setup
sudo -u root ln -s /etc/init.d/pm-setup.sh /etc/rc3.d/S08pm-setup
sudo -u root ln -s /etc/init.d/pm-setup.sh /etc/rc4.d/S08pm-setup
sudo -u root ln -s /etc/init.d/pm-setup.sh /etc/rc5.d/S08pm-setup
#sudo -u root update-rc.d pm-setup.sh defaults 

sudo -u root /usr/sbin/pm-setup

sudo -u root cp -f xdrv/penmount_drv.so  /usr/lib/xorg/modules/input

