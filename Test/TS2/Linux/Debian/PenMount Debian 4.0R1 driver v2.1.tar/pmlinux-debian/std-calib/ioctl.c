#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define HALF_DUPLEX_READ "/tmp/penmount_dat"
#define HALF_DUPLEX_WRITE "/tmp/penmount_cmd"

int DeviceIOControl(unsigned char *inbuf, int inbufLen, unsigned char *outbuf, int outbufLen)
{
    int fd1, fd2, ret_val, numread;


    // make named FIFO : /tmp/penmount_dat
    ret_val = mkfifo(HALF_DUPLEX_READ, 0666);
    if(ret_val == -1 && errno != EEXIST) {
        perror("Error createing named pipe");
        return(-1);
    }

    // make named FIFO : /tmp/penmount_cmd
    ret_val = mkfifo(HALF_DUPLEX_WRITE, 0666);
    if(ret_val == -1 && errno != EEXIST) {
        perror("Error creating named pipe");
        return(-1);
    }

    // open FIFO (std-calib --> xf86PM)
	fd1 = open(HALF_DUPLEX_WRITE, O_WRONLY);

    // inbuf --> FIFO:/tmp/penmount_cmd (std-calib --> xf86PM)
    write(fd1, inbuf, inbufLen );
    unlink(HALF_DUPLEX_WRITE);


    // open FIFO (xf86PM --> std-calib)
    fd2 = open(HALF_DUPLEX_READ, O_RDONLY);

    numread = read(fd2, outbuf, outbufLen);


    unlink(HALF_DUPLEX_READ);


	return numread;
}
