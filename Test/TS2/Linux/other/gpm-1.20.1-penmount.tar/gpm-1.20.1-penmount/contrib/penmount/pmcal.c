/*
 *  pmcal.c - PenMount calibration
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <sys/ioctl.h>

#include <linux/input.h>

#include <time.h>
#include <ncurses.h>
#include <wchar.h>

#define TERMIOS 1

#if TERMIOS
#include <termios.h>
#endif

#define DEFAULT_BAUDRATE    19200

char    device_name[32];
int     devfd;
char intf_type;

int     baudrate_list[18] = {
        50, 75, 110, 134, 150, 200, 300, 600, 1200, 1800, 
        2400, 4800, 9600, 19200, 38400, 57600, 115200, 230400
        };
    

int setBaudRate(struct termios *tios, int baud)
{
    int ret;

    switch(baud) {
        case 0:
            cfsetispeed(tios, B0);
            cfsetospeed(tios, B0);
            ret = B0;
            break;
        case 50:
            cfsetispeed(tios, B50);
            cfsetospeed(tios, B50);
            ret = B50;
            break;
        case 75:
            cfsetispeed(tios, B75);
            cfsetospeed(tios, B75);
            ret = B75;
            break;
        case 110:
            cfsetispeed(tios, B110);
            cfsetospeed(tios, B110);
            ret = B110;
            break;
        case 134:
            cfsetispeed(tios, B134);
            cfsetospeed(tios, B134);
            ret = B134;
            break;
        case 150:
            cfsetispeed(tios, B150);
            cfsetospeed(tios, B150);
            ret = B150;
            break;
        case 200:
            cfsetispeed(tios, B200);
            cfsetospeed(tios, B200);
            ret = B200;
            break;
        case 300:
            cfsetispeed(tios, B300);
            cfsetospeed(tios, B300);
            ret = B300;
            break;
        case 600:
            cfsetispeed(tios, B600);
            cfsetospeed(tios, B600);
            ret = B600;
            break;
        case 1200:
            cfsetispeed(tios, B1200);
            cfsetospeed(tios, B1200);
            ret = B1200;
            break;
        case 1800:
            cfsetispeed(tios, B1800);
            cfsetospeed(tios, B1800);
            ret = B1800;
            break;
        case 2400:
            cfsetispeed(tios, B2400);
            cfsetospeed(tios, B2400);
            ret = B2400;
            break;
        case 4800:
            cfsetispeed(tios, B4800);
            cfsetospeed(tios, B4800);
            ret = B4800;
            break;
        case 9600:
            cfsetispeed(tios, B9600);
            cfsetospeed(tios, B9600);
            ret = B9600;
            break;
        case 19200:
            cfsetispeed(tios, B19200);
            cfsetospeed(tios, B19200);
            ret = B19200;
            break;
        case 38400:
            cfsetispeed(tios, B38400);
            cfsetospeed(tios, B38400);
            ret = B38400;
            break;
        case 57600:
            cfsetispeed(tios, B57600);
            cfsetospeed(tios, B57600);
            ret = B57600;
            break;
        case 115200:
            cfsetispeed(tios, B115200);
            cfsetospeed(tios, B115200);
            ret = B115200;
            break;
        case 230400:
            cfsetispeed(tios, B230400);
            cfsetospeed(tios, B230400);
            ret = B230400;
            break;
    }
    
    return ret;
}
        

static int open_device(char *device_name, int baudrate)
{
    struct termios  termios;
    int baud_flag;

    //baudrate = DEFAULT_BAUDRATE;

    // exist ?
    if ( access(device_name, R_OK) ) {
        fprintf(stderr, "Device name %s not found\n", device_name);
        endwin();
        exit(0);
    }    

    //devfd = open(device_name, O_RDWR | O_NOCTTY | O_NONBLOCK);
    devfd = open(device_name, O_RDWR);
    if (devfd <= 0) {
        fprintf(stderr, "open device error! %s\n\r", device_name);
        return -1;
    } else {
        //fprintf(stderr, "open %s, ", device_name);
        fprintf(stderr, "Port : %s\n\r", device_name);
    }

    // read termios data
    if (tcgetattr(devfd, &termios) < 0)
        goto err;


    fprintf(stderr, "Baud : %d bps\n", baudrate);
    baud_flag = setBaudRate(&termios, baudrate);
    //cfsetispeed(&termios, B57600);
    //cfsetospeed(&termios, B57600);
    
    // debug
    //fprintf(stderr, "%d, %d\n", cfgetispeed(&termios), cfgetospeed(&termios));
    //fprintf(stderr, "B19200=%d, baud_flag=%d\n", B19200, baud_flag);

    termios.c_iflag     = IGNBRK | IGNPAR;
    termios.c_oflag     = 0;
    termios.c_lflag     = 0;
    termios.c_line      = 0;    
    termios.c_cc[VTIME] = 0;    
    termios.c_cc[VMIN]  = 0;    
    //termios.c_cflag = CS8 | CSTOPB | CREAD | CLOCAL | HUPCL | B19200;
    termios.c_cflag = CS8 | CSTOPB | CREAD | CLOCAL | HUPCL | baud_flag;

    if (tcsetattr(devfd, TCSAFLUSH, &termios) < 0)
        goto err;

    return devfd;

err:
    close(devfd);
    devfd = 0;
    return -1;
}

void close_device(void)
{
    if (devfd > 0)
        close(devfd);
    devfd = -1;
}

void show_message(void)
{
    fprintf(stderr, "Usage : pmcal [port] [baudrate]\n\n");
    fprintf(stderr, "  [port]        : /dev/ttyS[0-3]...etc\n");
    fprintf(stderr, "  [baudrate]    : 19200, 9600 bps\n\n");
    fprintf(stderr, "Example : \n");
    fprintf(stderr, "  pmcal /dev/ttyS0 19200    ( COM1, 19200 bps )\n");
    fprintf(stderr, "  pmcal /dev/ttyS1 9600     ( COM2,  9600 bps )\n");
    fprintf(stderr, "  pmcal /dev/input/event2   ( USB )\n");
}

static int maxx, maxy;
static int calx[4];
static int caly[4];
static int cal_flag;
static int cal_idx;

void nextpoint(void)
{
    clear();

//        mvprintw(maxy/2-1, maxx/2-11, "Please touch the cursor");
    switch(cal_idx) {
    case 0:
        mvprintw(2, maxx/4-2, "Please touch the cursor");
        move(0, maxx/4);
        break;
    case 1:
        mvprintw(maxy/4, maxx-26, "Please touch the cursor");
        move(maxy/4, maxx-1);
        break;
    case 2:
        mvprintw(maxy-3, maxx/4*3-12, "Please touch the cursor");
        move(maxy-1, maxx/4*3);
        break;
    case 3:
        mvprintw(maxy/4*3, 4, "Please touch the cursor");
        move(maxy/4*3, 0);
        break;
    }
    refresh();
}

void pm9calib(unsigned char head, int x, int y)
{
    FILE    *f;
    int        pmode;
    int        temp;
    int        cx[2], cy[2];
    

    if (cal_flag == 0 && head == 0xFF) {
        cal_flag = 1;
    } else if (cal_flag == 1 && head == 0xBF && cal_idx < 4) {
        calx[cal_idx] = x;
        caly[cal_idx++] = y;        
        nextpoint();
        head = 0;
        cal_flag = 0;
    }

    if (cal_idx >= 4) {
        //fprintf(stderr, "cal_idx >= 4");
        //fprintf(stderr, "calx : %d %d %d %d\n", calx[0], calx[1], calx[2], calx[3]);
        //fprintf(stderr, "caly : %d %d %d %d\n", caly[0], caly[1], caly[2], caly[3]);
        // pmode
        if ((calx[3]<calx[0] && calx[0]<calx[2] && calx[2]<calx[1]) &&
            (caly[0]<caly[1] && caly[1]<caly[3] && caly[3]<caly[2]))
            pmode = 1;
        else if ((calx[3]<calx[0] && calx[0]<calx[2] && calx[2]<calx[1]) &&
                 (caly[2]<caly[3] && caly[3]<caly[1] && caly[1]<caly[0]))
            pmode = 2;
        else if ((calx[1]<calx[2] && calx[2]<calx[0] && calx[0]<calx[3]) &&
                 (caly[0]<caly[1] && caly[1]<caly[3] && caly[3]<caly[2]))
            pmode = 3;
        else if ((calx[1]<calx[2] && calx[2]<calx[0] && calx[0]<calx[3]) &&
                 (caly[2]<caly[3] && caly[3]<caly[1] && caly[1]<caly[0]))
            pmode = 4;
        else if ((calx[0]<calx[1] && calx[1]<calx[3] && calx[3]<calx[2]) &&
                 (caly[3]<caly[0] && caly[0]<caly[2] && caly[2]<caly[1]))
            pmode = 5;
        else if ((calx[2]<calx[3] && calx[3]<calx[1] && calx[1]<calx[0]) &&
                 (caly[3]<caly[0] && caly[0]<caly[2] && caly[2]<caly[1]))
            pmode = 6;
        else if ((calx[0]<calx[1] && calx[1]<calx[3] && calx[3]<calx[2]) &&
                 (caly[1]<caly[2] && caly[2]<caly[0] && caly[0]<caly[3]))
            pmode = 7;
        else if ((calx[2]<calx[3] && calx[3]<calx[1] && calx[1]<calx[0]) &&
                 (caly[1]<caly[2] && caly[2]<caly[0] && caly[0]<caly[3]))
            pmode = 8;
        else
            pmode = 8;

        if (pmode >= 5) {
            cy[0] = calx[0];
            cy[1] = calx[2];
            cx[0] = caly[3];
            cx[1] = caly[1];
        } else {
            cy[0] = caly[0];
            cy[1] = caly[2];
            cx[0] = calx[3];
            cx[1] = calx[1];
        }

        if (cy[0] > cy[1]) {
            temp = cy[1];
            cy[1] = cy[0];
            cy[0] = temp;
        }
        if (cx[0] > cx[1]) {
            temp = cx[1];
            cx[1] = cx[0];
            cx[0] = temp;
        }
        //fprintf(stderr, "cx : %d %d\n", cx[0], cx[1]);
        //fprintf(stderr, "cy : %d %d\n", cy[0], cy[1]);
        //fprintf(stderr, "%d %d %d %d %d\n", pmode, cx[0], cx[1], cy[0], cy[1]);
        f = fopen("/etc/penmount.dat", "w");
        if (f) {
            fprintf(f, "%d %d %d %d %d\n", pmode, cx[0], cx[1], cy[0], cy[1]);
            fclose(f);
        }
        endwin();
        exit(0);
    }

}

void pm6calib(unsigned char head, int x, int y)
{
    FILE    *f;
    int        pmode;
    int        temp;
    int        cx[2], cy[2];
    

    if (cal_flag == 0 && head == 0x70) {
        cal_flag = 1;
    } else if (cal_flag == 1 && head == 0x30 && cal_idx < 4) {
        calx[cal_idx] = x;
        caly[cal_idx++] = y;        
        nextpoint();
        head = 0;
        cal_flag = 0;
    }

    if (cal_idx >= 4) {
        // pmode
        if ((calx[3]<calx[0] && calx[0]<calx[2] && calx[2]<calx[1]) &&
            (caly[0]<caly[1] && caly[1]<caly[3] && caly[3]<caly[2]))
            pmode = 1;
        else if ((calx[3]<calx[0] && calx[0]<calx[2] && calx[2]<calx[1]) &&
                 (caly[2]<caly[3] && caly[3]<caly[1] && caly[1]<caly[0]))
            pmode = 2;
        else if ((calx[1]<calx[2] && calx[2]<calx[0] && calx[0]<calx[3]) &&
                 (caly[0]<caly[1] && caly[1]<caly[3] && caly[3]<caly[2]))
            pmode = 3;
        else if ((calx[1]<calx[2] && calx[2]<calx[0] && calx[0]<calx[3]) &&
                 (caly[2]<caly[3] && caly[3]<caly[1] && caly[1]<caly[0]))
            pmode = 4;
        else if ((calx[0]<calx[1] && calx[1]<calx[3] && calx[3]<calx[2]) &&
                 (caly[3]<caly[0] && caly[0]<caly[2] && caly[2]<caly[1]))
            pmode = 5;
        else if ((calx[2]<calx[3] && calx[3]<calx[1] && calx[1]<calx[0]) &&
                 (caly[3]<caly[0] && caly[0]<caly[2] && caly[2]<caly[1]))
            pmode = 6;
        else if ((calx[0]<calx[1] && calx[1]<calx[3] && calx[3]<calx[2]) &&
                 (caly[1]<caly[2] && caly[2]<caly[0] && caly[0]<caly[3]))
            pmode = 7;
        else if ((calx[2]<calx[3] && calx[3]<calx[1] && calx[1]<calx[0]) &&
                 (caly[1]<caly[2] && caly[2]<caly[0] && caly[0]<caly[3]))
            pmode = 8;
        else
            pmode = 8;

        if (pmode >= 5) {
            cy[0] = calx[0];
            cy[1] = calx[2];
            cx[0] = caly[3];
            cx[1] = caly[1];
        } else {
            cy[0] = caly[0];
            cy[1] = caly[2];
            cx[0] = calx[3];
            cx[1] = calx[1];
        }

        if (cy[0] > cy[1]) {
            temp = cy[1];
            cy[1] = cy[0];
            cy[0] = temp;
        }
        if (cx[0] > cx[1]) {
            temp = cx[1];
            cx[1] = cx[0];
            cx[0] = temp;
        }
        f = fopen("/etc/penmount.dat", "w");
        if (f) {
            fprintf(f, "%d %d %d %d %d\n", pmode, cx[0], cx[1], cy[0], cy[1]);
            fclose(f);
        }
        endwin();

		close_device();
        exit(0);
    }
}

int main(int ac, char **av)
{
    unsigned char   buf[16];
    unsigned char   pbuf[16];
    unsigned char   sum;
    int bytes_read;
    int rate;
    int i, j;
    int cnt, bcnt;
    int sec;
    unsigned char   pm_type;
    
    time_t  t;
    struct tm *ct;

    //int             i;
    int             px, py;
    struct input_event *event;
    unsigned char ebuf[256];
    int	x, y;
    unsigned char flag;
    int len;

    intf_type = 0xFF;
   
    if (ac < 2) {
        show_message();
        return -1;
    }

    if (access("/var/run/gpm.pid", F_OK)==0) {
    fprintf(stderr, "Please stop gpm service using 'service gpm stop' or 'gpm -k'\n");
    return 0;
    }

    initscr();
    //keypad(stdscr, TRUE);
    //nonl();
    cbreak();
    noecho();
    maxx = getmaxx(stdscr);
    maxy = getmaxy(stdscr);

    cal_flag = 0;
    cal_idx = 0;
    cnt = 0;
    bcnt = 0;
    bytes_read = 0;
    pm_type = 0;
    
    if (ac >= 3)
        rate = atoi(av[2]);
    else
        rate = 19200;

    strcpy(device_name, av[1]);

    if (strstr(device_name, "/dev/input/event")) {
        intf_type = 1;
    } else {
        intf_type = 0;
        for (i=0; i<sizeof(baudrate_list)/sizeof(baudrate_list[0]); i++) {
            if ( rate == baudrate_list[i])
                break;
        }
        if (i == sizeof(baudrate_list)/sizeof(baudrate_list[0])) {
            fprintf(stderr, "baudrate error : %d\n", rate);
            endwin();
            return -1;
        }
    }
    

    if (intf_type == 0) {
        // open tty
        if (open_device(device_name, rate) < 0) {
            fprintf(stderr, "open device error!\n");
            endwin();
            return -1;
        }
    } else if (intf_type == 1) {
        devfd = open(device_name, O_RDONLY);
        if (!devfd) {
            fprintf(stderr, "open device error!\n");
            endwin();
            return -1;
        }
            
    }

    if (intf_type == 0) {
        j = 0;
        time(&t);
        ct = localtime(&t);
        sec = ct->tm_sec;
        sec += 2;
        if (sec > 60)
            sec -= 60;
        while (1) {
            bytes_read = read(devfd, buf, sizeof(buf));

            time(&t);
            ct = localtime(&t);
            if (sec == ct->tm_sec)
                break;
        }
    }

    if (intf_type == 0) {
        // enable 6000
        pbuf[0] = 0xf1;
        pbuf[1] = 0;
        pbuf[2] = 0;
        pbuf[3] = 0;
        pbuf[4] = 0;
        pbuf[5] = 0x0e;
        write(devfd, pbuf, 6);
    
        for (i=0; i<6; i++)
            pbuf[i] = 0;

        time(&t);
        ct = localtime(&t);
        sec = ct->tm_sec;
        sec += 3;
        if (sec > 60)
            sec -= 60;
    }
    
    if (cal_idx == 0)
        nextpoint();

	if (intf_type == 0) {

    j = 0;
    while (1) {
        bytes_read = read(devfd, buf, sizeof(buf));
        if (bytes_read) {
            for (i=0; i<bytes_read; i++)
                pbuf[j++] = buf[i];
        }

        if (j >= 5) {
            if (pbuf[0] == 0xf1 && pbuf[1] == 0 && pbuf[2] == 0 &&
                pbuf[3] == 0x00 && pbuf[4] == 0 && pbuf[5] == 0x0e) {
//                fprintf(stderr, "PenMount 6000 found! \n");
        		mvprintw(2, maxx/4-2, "PenMount 6000 found!");
                pm_type = 6;
                break;
            } else if ( pbuf[0] == 0xf1 && pbuf[1] == 0 && pbuf[2] == 0 &&
                        pbuf[3] == 0x00 && pbuf[4] == 0) {
//                fprintf(stderr, "PenMount 9000 found! \n");
        		mvprintw(2, maxx/4-2, "PenMount 9000 found!");
                pm_type = 9;
                break;
            } 
            //fprintf(stderr, "%02x %02x %02x %02x %02x %02x \n",
            //    pbuf[0], pbuf[1], pbuf[2], pbuf[3], pbuf[4], pbuf[5]);
            break;
        }

        time(&t);
        ct = localtime(&t);
        if (sec == ct->tm_sec) {
//            fprintf(stderr, "PenMount not found! \n");
       		mvprintw(2, maxx/4-2, "PenMount not found!");
            close_device();
            endwin();
            exit(0);
        }

    }
	} //if intf_type
    
    for (j=0; j<6; j++)
        pbuf[j++] = 0;
   

    if (intf_type == 0) {
 
    j = 0;
    while (1) {
        bytes_read = read(devfd, buf, sizeof(buf));

        if (bytes_read) {
            for (i=0; i<bytes_read; i++) {
                // 9000
                if (pm_type == 9) {
                    if ( buf[i] & 0x80 ) {
//                        fprintf(stderr, "%5d : ", ++cnt);
                        pbuf[0] = buf[i];
                        j = 1;
                    } else {
                        if (j == 1) {
                            px = buf[i];
                            pbuf[1] = buf[i];
                        } else if (j == 2) {
                            px <<= 7;
                            px += buf[i];
                            pbuf[2] = buf[i];
                        } else if (j == 3) {
                            py = buf[i];
                            pbuf[3] = buf[i];
                        } else if (j == 4) {
                            py <<= 7;
                            py += buf[i];
                            pbuf[4] = buf[i];
                            j = 0;
/*
                            fprintf(stderr, "%02x %02x %02x %02x %02x  (%5d, %5d) ",
                                pbuf[0], pbuf[1], pbuf[2], pbuf[3], pbuf[4], px, py);
*/
                            pm9calib(pbuf[0], px, py);
                            //if (pbuf[0] == 0xbf)
                            //    fprintf(stderr, "Up\n");
                            //else if (pbuf[0] == 0xff)
                            //    fprintf(stderr, "Down\n");
                            //else
                            //    fprintf(stderr, "Error\n");
                        }
                        j++;
                    }
                } else if (pm_type == 6) {
                    // 6000
                    if (j < 15)
                        pbuf[j++] = buf[i];

                    if (j >= 6) {
                        for(j=0, sum=0; j<5; j++)
                            sum += pbuf[j];
                        sum = 0xff - sum;
                        if (sum == pbuf[5]) {
                            //fprintf(stderr, "%5d : ", ++cnt);

                            px = pbuf[2];
                            px <<= 8;
                            px += pbuf[1];

                            py = pbuf[4];
                            py <<= 8;
                            py += pbuf[3];

                            //fprintf(stderr, "%02x %02x %02x %02x %02x %02x  (%5d, %5d) ",
                            //    pbuf[0], pbuf[1], pbuf[2], pbuf[3], pbuf[4], pbuf[5], px, py);

                            pm6calib(pbuf[0], px, py);
                            //if (pbuf[0] == 0x30)
                            //    fprintf(stderr, "Up\n");
                            //else if (pbuf[0] == 0x70)
                            //    fprintf(stderr, "Down\n");
                            //else
                            //    fprintf(stderr, "Error\n");
                            j = 0;
                        } else {
                            //fprintf(stderr, "%5d : ", ++cnt);
                            // sync
                            for (j=0; j<5; j++)
                                pbuf[j] = pbuf[j+1];
                            j = 5;
                        }
                    }
                }//pm_type == 6
            }//for-bytes_read
        }//if-bytes_read
    }//while

    close_device();

    }//if intf_type

	if (intf_type == 1) {
        while (1) {
            len = read(devfd, ebuf, 256);
            for (event = (struct input_event *)ebuf;
                 event < (struct input_event *)(ebuf+len); event++) {
                switch(event->type) {
                case EV_ABS:
                    switch(event->code) {
                    case ABS_X:
                        x = event->value;
                        flag |= 0x01;
                        break;
                    case ABS_Y:
                        y = event->value;
                        flag |= 0x02;
                        break;
                    break;
                    }
                case EV_KEY:
                    if (event->code == BTN_LEFT)
                        bcnt++;
                    break;
                }//switch

                if ((flag & 0x03) == 3) {
                    if (bcnt < 2) {
                        pm6calib(0x70, x, y);
                    } else {
                        pm6calib(0x30, x, y);
                        bcnt = 0;
                    }
                    flag = 0;
                }
            }//for
        }//while
    }
    return 0;
}
