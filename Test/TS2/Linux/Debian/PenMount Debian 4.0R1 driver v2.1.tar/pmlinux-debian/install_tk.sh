#!/bin/bash

sudo apt-get install tk8.4
