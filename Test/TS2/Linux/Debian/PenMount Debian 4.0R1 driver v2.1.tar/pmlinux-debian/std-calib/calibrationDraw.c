#include "color.h"
#include "calibrationDraw.h"
#include "unistd.h"

//---------------------------------------------------------------------------
// Local functions declaration
//---------------------------------------------------------------------------
void Draw(Display *display, Drawable d, GC gc, int x, int y);
void DrawArrow(Display *display, Drawable d, GC gc, int x, int y, int len);

static int Width = 0;
static int Height = 0;
static int ToggleState = 0;
static Display *display;
static Drawable d;
static GC gc;
static XFontStruct *font_info = NULL;

static char *prompt_touch_string = "Touch the red square inside the blue circle.";

unsigned long color;

//---------------------------------------------------------------------------
void DrawPromptString(char *prompt)
{
    int string_width = XTextWidth(font_info, prompt, strlen(prompt));
    int font_height  = font_info->ascent + font_info->descent;
	int x = (Width - string_width) / 2;
    int y = (Height - font_height) / 2;

    XDrawString(display, d, gc, x, y, prompt, strlen(prompt));
}

void SetScreenDimension(Display *dpy, Drawable drw, GC g, int width, int height,XFontStruct* font)
{
    display   = dpy;
    d         = drw;
	gc        = g;	
	Width     = width;
	Height    = height;
	font_info = font;
}
//---------------------------------------------------------------------------
#define EDGE_OFFSET 5

void ShowPoint(int calibPointsNum, int state)
{
    float x,y;
    int i = 0;

    switch(state) {
        case 0:
            x = Width * 0.25;
            y = EDGE_OFFSET;
            break;
        case 1:
            x = Width - EDGE_OFFSET;
            y = Height * 0.25;
            break;
        case 2:
            x = Width * 0.75;
            y = Height - EDGE_OFFSET;
            break;
        case 3:
            x = EDGE_OFFSET;
            y = Height * 0.75;
            break;
        case 4:
            x = Width * 0.3;
            y = Height * 0.7;
            break;
        default:
            x = 0;
            y = 0;
            break;
    }	

    XClearArea(display, d, 0, 0, Width, Height, False);
    DrawPromptString(prompt_touch_string);

    ToggleState = 0;

    for(i = 0; i < 15; i++) {
        Draw(display, d, gc, x, y);
        usleep(20000);
    }
}

//---------------------------------------------------------------------------
#define ARROW_WIDTH  5
#define ARROW_HEIGHT 20

void DrawArrow(Display *display, Drawable d, GC gc, int x, int y, int len)
{
    XPoint points[3];
    points[0].x = x;
    points[0].y = y - len;
    points[1].x = x + ARROW_WIDTH;
    points[1].y = y - ARROW_HEIGHT - len;
    points[2].x = x - ARROW_WIDTH;
    points[2].y = y - ARROW_HEIGHT - len;
    XFillPolygon(display, d, gc, points, 3, Convex, CoordModeOrigin);

    points[0].x = x+len;
    points[0].y = y;
    points[1].x = x + ARROW_HEIGHT + len;
    points[1].y = y + ARROW_WIDTH;
    points[2].x = x + ARROW_HEIGHT + len;
    points[2].y = y - ARROW_WIDTH;
    XFillPolygon(display, d, gc, points, 3, Convex, CoordModeOrigin);

    points[0].x = x;
    points[0].y = y + len;
    points[1].x = x + ARROW_WIDTH;
    points[1].y = y + ARROW_HEIGHT + len;
    points[2].x = x - ARROW_WIDTH;
    points[2].y = y + ARROW_HEIGHT + len;
    XFillPolygon(display, d, gc, points, 3, Convex, CoordModeOrigin);

    points[0].x = x - len;
    points[0].y = y;
    points[1].x = x - ARROW_HEIGHT - len;
    points[1].y = y + ARROW_WIDTH;
    points[2].x = x - ARROW_HEIGHT - len;
    points[2].y = y - ARROW_WIDTH;
    XFillPolygon(display, d, gc, points, 3, Convex, CoordModeOrigin);

}

void Draw(Display *display, Drawable d, GC gc, int x, int y)
{
    if (ToggleState < 12) {

        XClearArea(display, d, x-50, y-50, 100, 100, False);

        if (get_color(display, 0, "Blue", &color) == 0)
            XSetForeground(display, gc, color);
            
        XDrawArc(display, d, gc, x-20, y-20, 40, 40, 0, 360*64);

        if (ToggleState < 4)
            DrawArrow(display, d, gc, x, y, 14);
        else
            DrawArrow(display, d, gc, x, y, 14-ToggleState);

        XSetForeground(display, gc, WhitePixel(display, 0));

        ToggleState++;

    } else {
        XClearArea(display, d, x-50, y-50, 100, 100, False);
        ToggleState = 0;
    }

    if (ToggleState == 0)
        DrawPromptString(prompt_touch_string);

    if (get_color(display, 0, "Red", &color) == 0)
        XSetForeground(display, gc, color);

    XDrawRectangle(display, d, gc, x-2, y-2, 4 ,4);
    XSetForeground(display, gc, WhitePixel(display, 0));
    XFlush(display);
}
