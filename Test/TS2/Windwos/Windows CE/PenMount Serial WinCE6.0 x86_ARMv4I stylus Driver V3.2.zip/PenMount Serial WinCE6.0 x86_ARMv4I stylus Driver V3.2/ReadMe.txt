#   Copyright (c) By Dialogue Technology Corp. All rights reserved.
#   07/02/2009
#############################################################################

PenMount Serial Driver Package for Windows CE.Net 6.0

1. Copy PenMount to $(_WINCEROOT)\Public

2. Please edit tchmdd.reg for hardware configuration like "Port"(for com port
   number), "Baudrate",and "Protocol"(choose control board). For example:
   
   "Port"=dword:1             ; the com-port number you are used to connect 
                              ; to PenMount controller.

   "Protocol"=dword:1         ; for PM9000
   "Protocol"=dword:3         ; for PM6000R (Serial)

   "Baudrate"=dword:2580      ; 9600
   "Baudrate"=dword:4B00      ; 19200

3. Open your OSDesign.

4. Refresh "Catalog Items View". If you can't see "PenMount2 XXX"

5. Check the box of "PenMount2 XXX" item.

6. Build "Subprojects--> XXX". If your OSDesign had built.
   Or You must build your OSDesign.

