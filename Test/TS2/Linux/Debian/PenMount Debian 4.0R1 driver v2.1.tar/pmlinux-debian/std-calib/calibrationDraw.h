#ifndef __CALIBRATIONDRAW_H_
#define __CALIBRATIONDRAW_H_

#include <X11/Xlib.h>
#include "color.h"

void SetScreenDimension(Display *dpy, Drawable drw, GC g, int width, int height, XFontStruct* font);
void ShowPoint(int calibPointsNum, int state);
void Clear();
void DrawTable();

#endif
