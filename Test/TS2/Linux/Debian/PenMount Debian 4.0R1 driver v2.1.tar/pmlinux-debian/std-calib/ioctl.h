#ifndef __IOCTL_H
#define __IOCTL_H

#define IOCTL_DATA_BUFFER_LEN 5
#define IOCTL_COMMAND_BUFFER_LEN 10
#define IOCTL_SET_CALIBRATION 0xFE
int DeviceIOControl(unsigned char *inbuf, int inbufLen, unsigned char *outbuf, int outbufLen);

#endif
