+---------------------------+
| COPYRIGHT (C) by PenMount |
+---------------------------+

PenMount Touch Screen Kits is a turn-key solution to upgrade your product
to have touching function.  PenMount product supports DOS, Windows,
Windows 95, Windows NT, Windows 2000, Windows XP and OS/2 operating system
under PC environment.



=============================
A. PenMount Touch Screen Kits
=============================

PenMount Touch Screen Kits include four items:
a. Touch screen
b. PenMount Controller board or ASIC
c. PenMount Driver diskette
d. Manual

The driver diskette includes DOS drivers


==============================
B. PenMount DOS driver package
==============================
The PenMount DOS driver version 2.10 diskette is consist of the following files:

INSTALL.EXE  -- PenMount installation program
PM2.EXE      -- PenMount Utility, to configure or test the PenMount touch screen
PMOUSE.EXE   -- Driver loader, to load or unload driver.
PMTSR.COM    -- PenMount DOS Driver
PMOUSE.CFG   -- The configuration file for PenMount DOS driver
README.TXT   -- The file you're reading now.
PMINIT.BAT   -- Reload DOS driver batch file
PMUNLOAD.BAT -- Unload DOS driver batch file
PMTEST.EXE   -- PenMount driver test utility to verify PenMount driver working.
MOUSETST.COM -- Mouse Test utility




========================================================
C. HOW TO INSTALL PENMOUNT DOS  DRIVERS TO YOUR COMPUTER
========================================================

1. Before Installation
----------------------
    o PenMount touch screen RS-232 connector is 9-pin D-sub connector.
    o Plug into the COM port of PC. (e.g  COM1, COM2, COM3 or COM4)


2. Install PenMount DOS driver
------------------------------
Step 1  Uncompress the driver package. (e.g. C:\TEMP)

Step 2  Change the working directory. (e.g. cd \TEMP)

Step 3  Run the installation program 'install.exe" at DOS prompt.

Step 4  The install.exe will lead you to complete the installation.

Step 5  Restart computer (Recommanded)
        or
        press 'ESC' key and issue 'SET PENMOUNT=<penmount_installation_path>' at DOS prompt.
        
Step 6  The PenMount driver will be loaded after restarting computer.


3. Environment Variable - PENMOUNT
----------------------------------
    The environment variable, PENMOUNT, is needed for PenMount driver v2.10.
The installation program will put the command line 'SET PENMOUNT=<penmount_install_path>'
into the AUTOEXEC.BAT, like :

    SET PENMOUNT=C:\PM2     (e.g. PenMount installation path is C:\PM2)

    The driver can't be loaded, if the enviroment variable is not configured properly
and the utility can't be run. Issue the command 'set' at DOS prompt to check the
environment variable.


4. Environment Variable - PATH
------------------------------
    The installation program will put the installation path into the environment
PATH. You can run program in any working directory at DOS prompt regardless of
where the working directory is.


=============================
D. HOW TO USE PENMOUNT IN DOS
=============================

1. PM2 Panel
------------
    Run the batch file 'PM2.EXE'. Type the command at DOS prompt:
    
    PM2
    
    Before runnugn PM2, you must remove PenMount driver or another
    mouse driver, if you're installed.

    There are several functions to select, and the launch key is
    in brackets. (e.g. press '2' key to do calibration)
    
    Use <arrow key> (up/down) to select, and <Enter> to launch

    (1) Draw
    (2) Calibrate
    (3) Detect
    (4) Configure
    (5) Packet
    (6) Help
    (7) Exit


2. Draw
-------
    Run the 'Draw' in PM2 Panel, and using the arrow keys or hot keys(A~Y) to 
    choose one of 25 video modes.

    Video modes :
    
    mode    width   height  colors
    ----------------------------------
     0Dh     320     200    16
     13h     320     200    256
    10Dh     320     200    32K
    10Eh     320     200    64K
    10Fh     320     200    16M
     0Eh     640     200    16
     10h     640     350    16
    100h     640     400    256
     12h     640     480    16
    101h     640     480    256
    110h     640     480    32K
    111h     640     480    64K
    112h     640     480    16M
    103h     800     600    256
    113h     800     600    32K
    114h     800     600    64K
    115h     800     600    16M
    105h    1024     768    256
    116h    1024     768    32K
    117h    1024     768    64K
    118h    1024     768    16M
    107h    1280    1024    256
    119h    1280    1024    32K
    11Ah    1280    1024    64K
    11Bh    1280    1024    16M
    ----------------------------------
    


    There are several function keys in the drawing screen :

    [ESC]   - exit

    [Space] - clear screen and information

    [F1]    - help, list the function keys

    [F2]    - style, toggle line or dot.
              Line mode is default.
              Dot mode is that don't draw line between dot and next dot.

    [F3]    - frame, show / hide the frame

    [F4]    - hide, show / hide the status bar at bottom of screen

    [F5]    - pen color
              There are 16 colors of pen color :
              rainbow, blue, green, cyan, red, magenta, brown, lightgray,
              darkgray, lightblue, lightgreen, lightcyan, lightred,
              lightmagenta, yellow and white.

    [F6]    - highlight, highlight the dot in the line mode.

    [F9]    - camera, you can get the snapshot, and store it in bitmap file (BMP).
              The filename is 'PM<HHMMSS>.BMP', <HHMMSS> is hour, minute
              and second. The resoltion of bitmap file is the same as video
              mode, and the color depth is 4 bits.(16colors)


    Status bar :

    640x480 - screen resolution (320x200, 640x480....etc)
    S:      - number of dots were received per second.
    pen     - pen color
    P:      - the counter of received dots
    D:      - the counter of pen down
    U:      - the counter of pen up
    (x,y)   - current coordinate of dot
    x:y:    - minimum value of coordinate
    X:Y:    - maximum value of coordinate


3. Calibrate
------------
    Run the 'Calibrate' in PM2 Panel, and choose one of 25 video modes.

    It's to adjust the touch screen mapping properly to display screen.

    The display will ask you to select video mode number, select by
    keyboard your display mode to start the calibration.

    Touch the upper point, then touch the right point, bottom point and
    left point, and press <Enter> key to pass the point. After calibration,
    the calibrated data will be showed in the screen.

    After calibration, we recommand you to do drawing test to verify
    the touch screen and monitor mapped properly.


    Function Keys :
    [Enter]   - pass current point
    [F9]      - camera, see above.


4. Detect
---------
    Detect PenMount automatically. You can press any key to abort the detection.

    Use the following list to detect PenMount :
    COM1 (Base 03F8) (Baud 19200): IRQ 3, 4
    COM2 (Base 03F8) (Baud 19200): IRQ 3, 4
    COM3 (Base 03F8) (Baud 19200): IRQ 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15
    COM4 (Base 03F8) (Baud 19200): IRQ 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15

    COM1 (Base 03F8) (Baud 9600) : IRQ 3, 4
    COM2 (Base 03F8) (Baud 9600) : IRQ 3, 4
    COM3 (Base 03F8) (Baud 9600) : IRQ 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15
    COM4 (Base 03F8) (Baud 9600) : IRQ 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15

    If you can not find the PenMount, come 'configure' to set your COM port.


4. Configure
------------
    COM Port : COM5~COM9 is for customize setting.
    IRQ no.  : IRQ3~IRQ15
    I/O base : COM1~COM4 is fixed, COM5~COM9 is customzed.
    Baud     : 19200 / 9600
    Calibrate: left, right, top, and bottom point.
    POMODE   : the relationship between touch panel and monitor.
    Beep Duration : beep duration time (0ms~5500ms), 0ms  = turn off the beep
    Beep Freq     : beep frequency (20Hz ~ 10000 Hz)
    
    Other customized configurations in PenMount 6000 :

    . jitter threshold
    . SSD threshold
    . Z threshold
    . pen-up threshold
    . digital filter


    Function Key:
    
    [ESC]   - exit
    [Tab]   - toggle the fields
    [up]    - increase value
    [down]  - decrease value
    [right] - increate value by 100 (Beep Freq)
    [left]  - decreate value by 100 (Beep Freq)
    [Enter] - save configure and exit
        

5. Packet
---------
    By using it, you could get the touch's data, touching the screen 
    and see the getting data.

    The output format is :
    
    <counter>    : counter of raw data
        *        : current dot
    <raw data>   : the raw data of touch
    <coordinate> : the X, Y of A/D
    <offset>     : the offset between last dot
    
    Function Key:
    [ESC]   - exit


6. Help
-------
    See 'README.TXT' file
    


7. Test
-------
    Before test, you must check the driver is loaded.
    
    <1> To test program is named 'MOUSETST.EXE' ,
        You can run it with parameter:
    
        MOUSETST 18
    
        The parameter is video mode number:
        mode 18 (12h) : 640x480x16color
        mode 19 (13h) : 320x240x256color
        ....
    
        or run
    
        MOUSETST
    
        to see what parameters are
        
    <2> run pmtest.exe
    
    <3> edit
        You can also run 'EDIT', the editor boudle in MS-DOS.



PenMount
07.2008
