#!/bin/bash

cp -f xdrv-adv/penmount_drv.so /usr/lib/xorg/modules/input

cp -f pm-setup /usr/sbin
cp -f pm-setup.sh /etc/init.d
ln -s /etc/init.d/pm-setup.sh /etc/rc2.d/S08pm-setup
ln -s /etc/init.d/pm-setup.sh /etc/rc3.d/S08pm-setup
ln -s /etc/init.d/pm-setup.sh /etc/rc4.d/S08pm-setup
ln -s /etc/init.d/pm-setup.sh /etc/rc5.d/S08pm-setup

/usr/sbin/pm-setup

