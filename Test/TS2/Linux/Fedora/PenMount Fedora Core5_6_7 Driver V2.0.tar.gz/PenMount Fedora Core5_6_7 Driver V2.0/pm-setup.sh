#!/bin/bash

/usr/sbin/pm-setup -s
