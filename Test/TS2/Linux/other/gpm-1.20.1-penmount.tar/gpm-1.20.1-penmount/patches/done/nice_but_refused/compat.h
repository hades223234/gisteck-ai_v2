#define TTY_NAME_MAX 32

const char * get_virtualconsole0( void );
const char * get_virtualconsole_base( void );
const char * get_virtualscreen0( void );
const char * get_virtualscreen_base( void );
