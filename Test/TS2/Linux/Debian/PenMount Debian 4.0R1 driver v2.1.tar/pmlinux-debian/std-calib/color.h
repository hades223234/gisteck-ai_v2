#ifndef __COLOR_H_
#define __COLOR_H_

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xos.h>
#include <stdio.h>

int     get_color(Display *display, int screen_num, char *name, unsigned long *color);

#endif
