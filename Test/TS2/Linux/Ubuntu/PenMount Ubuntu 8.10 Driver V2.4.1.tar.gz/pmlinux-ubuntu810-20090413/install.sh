#!/bin/bash

filetime="$(date +%m%d%H%M%S)"
sudo cp /etc/X11/xorg.conf /etc/X11/xorg.conf.$filetime
sudo cp -f xorg.conf /etc/X11/xorg.conf

sudo mkdir /usr/share/penmount
sudo chown -R root.root *
sudo cp -f penmount.png     /usr/share/penmount
sudo cp -f README-ubuntu810 /usr/share/penmount

sudo cp -f penmount.dat     /etc
sudo cp -f pm-setup         /usr/sbin
sudo cp -f gCal             /usr/sbin
sudo cp -f penmount         /usr/sbin
sudo cp -f penmount48.png   /usr/share/icons/gnome/48x48/apps/penmount.png
sudo cp -f penmount32.png   /usr/share/icons/gnome/32x32/apps/penmount.png
sudo cp -f penmount24.png   /usr/share/icons/gnome/24x24/apps/penmount.png
sudo cp -f penmount22.png   /usr/share/icons/gnome/22x22/apps/penmount.png
sudo cp -f penmount16.png   /usr/share/icons/gnome/16x16/apps/penmount.png
sudo cp -f penmount.desktop /usr/share/applications

sudo mkdir ~/.config
sudo mkdir ~/.config/autostart
sudo cp -f penmount_autostart.desktop ~/.config/autostart/penmount.desktop

sudo /usr/sbin/pm-setup -s
sudo cp -f penmount_drv.so  /usr/lib/xorg/modules/input

