//==========================================================================
// Event device driver for PenMount LPC touchscreen (Flybook)
// Licence GPL
//
// Driver written by Heikki Linnakangas <heikki.linnakangas@iki.fi>
// Driver modified by Elmar Hanlhofer development@plop.at http://www.plop.at
// Driver modified by Christoph Pittracher <pitt@segfault.info>
// Driver modified by Richard Fan <richard@dialogue.com.tw>
//
// Changelog:
//
//   20080825 fix small issues, cleanup by Richard Fan
//   20080529 fixed small 2.6.24 issues by Elmar Hanlhofer
//   20060113 fixed small 2.6.15 issues by Christoph Pittracher
//   20050902 cleanup, irq data check by Christoph Pittracher
//   20050624 init sequence and timeout optimized by Elmar Hanlhofer
//   20050622 some evbit fixes by Christoph Pittracher
//   20050617 added init sequence and more debug messages by Elmar Hanlhofer
// 
//==========================================================================

#include <linux/input.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/delay.h>

#include <asm/irq.h>
#include <asm/io.h>

MODULE_AUTHOR("Heikki Linnakangas <heikki.linnakangas@iki.fi>");
MODULE_DESCRIPTION("Penmount LPC touchscreen driver");
MODULE_LICENSE("GPL");

#define PMLPC_IRQ       6
#define PMLPC_DAT_PORT  0x338
#define PMLPC_CMD_PORT  0x33c
#define PMLPC_STS_PORT  PMLPC_CMD_PORT
#define PMLPC_INITMAX   5
#define PMLPC_TIMEOUT   25000

#define STS_OBF         0x01
#define STS_IBE         0x02

#define CMD_DISABLE_TX	0xf0
#define CMD_ENABLE_TX	0xf1
#define CMD_VERSION     0xf2
#define CMD_DISABLE_INT	0xf8
#define CMD_ENABLE_INT	0xf9
#define CMD_DISABLE_DEV	0xfa
#define CMD_ENABLE_DEV	0xfb


struct input_dev* penmount_dev;
static unsigned char data[5];
static int	data_idx;
static unsigned char data0;


static void poll_penmount(void)
{
    unsigned char   sts;
    unsigned short  x, y;
    int             cnt;
    unsigned char   d;

    cnt = 1;

    while(cnt--) {
        sts = inb_p(PMLPC_STS_PORT);
        if (sts & STS_OBF) {
            d = inb_p(PMLPC_DAT_PORT);
            if ((d & 0x80) || data_idx >= 5)
                data_idx = 0;
            data[data_idx++] = d;
            
            if (data_idx >= 5 && (data[0]==0xbf || data[0]==0xff)) {
                x = data[1] & 0x7f;
                x <<= 7;
                x += (data[2] & 0x7f);
                y = data[3] & 0x7f;
                y <<= 7;
                y += (data[4] & 0x7f);
                input_report_abs(penmount_dev, ABS_X, x);
                input_report_abs(penmount_dev, ABS_Y, y);
                input_report_key(penmount_dev, BTN_TOUCH, !!(data[0]&0x40));
                input_sync(penmount_dev);
	            data0 = data[0];
	        }
            break;
        }
    }/* while */
}

//static irqreturn_t penmount_interrupt(int irq, void *dummy, struct pt_regs *fp) {
static irqreturn_t penmount_interrupt(int irq, void *dummy)
{
    poll_penmount();
    return IRQ_HANDLED;
}

static int __init penmount_init(void)
{

    unsigned short initPorts[] = 
      { PMLPC_CMD_PORT,
        PMLPC_CMD_PORT,
        PMLPC_CMD_PORT,
        PMLPC_DAT_PORT,
        PMLPC_CMD_PORT,
        PMLPC_CMD_PORT};
    unsigned char initWData[] =  { 0xf8, 0xfb, 0xf0, 0xf2, 0xf1, 0xf9 };
    unsigned char initRData[] =  { 0x09, 0x09, 0x09, 0xf0, 0x09 };
    int initDataCount = 0;
    int timeout;

    for (initDataCount = 0; initDataCount < PMLPC_INITMAX; initDataCount++) {

        /* 0xf8  --> port 0x33C : disable int (mcu) */
        /* 0xfb  --> port 0x33C : enable device     */
        /* 0xf0  --> port 0x33C : disable tx        */
        /* 0xf2  --> port 0x338 : get firmware version */
        /* 0xf1  --> port 0x33C : enable tx         */
        outb_p(initWData[initDataCount], initPorts[initDataCount]);
        timeout = PMLPC_TIMEOUT;

        while (timeout-- && initRData[initDataCount] != inb_p(initPorts[initDataCount]))
            udelay(10);

        if (timeout == 0) {
            printk(KERN_ERR "penmountlpc : penmount_init timeout\n");
            return -EPERM;
        }
    }
    /* 0xf9 --> 0x33C : enable int (mcu) */
    outb_p(initWData[PMLPC_INITMAX], initPorts[PMLPC_INITMAX]);
    
    data0 = 0xbf;
    
    if (request_irq(PMLPC_IRQ, penmount_interrupt, 0, "penmountlpc", NULL))
        return -EBUSY;

    penmount_dev = input_allocate_device();
    if (!penmount_dev)
        return -ENOMEM;

    penmount_dev->name = "PenmountLPC TouchScreen";
    penmount_dev->id.bustype = BUS_ISA;
    penmount_dev->id.vendor  = 0x14e1;
    penmount_dev->id.product = 0xfbfb;
    penmount_dev->id.version = 0x0003;
    
    sprintf(penmount_dev->phys, "%s/input0", "isa0338/serio0");

    input_set_abs_params(penmount_dev, ABS_X, 0, 1023, 0, 0);
    input_set_abs_params(penmount_dev, ABS_Y, 0, 1023, 0, 0);

    penmount_dev->evbit[0] = BIT(EV_ABS) | BIT(EV_KEY);
    penmount_dev->absbit[BIT_WORD(ABS_X)] = BIT(ABS_X);
    penmount_dev->absbit[BIT_WORD(ABS_Y)] |= BIT(ABS_Y);
    penmount_dev->keybit[BIT_WORD(BTN_TOUCH)] = BIT_MASK(BTN_TOUCH);
  
    input_register_device(penmount_dev);
    printk(KERN_INFO "penmountlpc : init finished\n");

    return 0;
}

static void __exit penmount_exit(void)
{
    input_unregister_device(penmount_dev);
    free_irq(PMLPC_IRQ, NULL);
    printk(KERN_ERR "penmountlpc.c: driver removed\n");
}

module_init(penmount_init);
module_exit(penmount_exit);
