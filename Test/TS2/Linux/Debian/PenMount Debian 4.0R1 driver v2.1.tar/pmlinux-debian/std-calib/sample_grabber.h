#ifndef __SAMPLE_GRABBER_H
#define __SAMPLE_GRABBER_H

#include <stdio.h>
#include <errno.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>

void *IOWorkerThread(void* arg);

#endif
