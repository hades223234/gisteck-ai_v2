#   Copyright (c) By Dialogue Technology Corp. All rights reserved.
#   07/02/2009
#############################################################################

PenMount Serial Driver Package for Windows CE.Net 5.0

1. Copy PenMount to $(_WINCEROOT)\Public

2. Run Platform Builder. From menu, select Tools -> CEC Editors

3. From CEC Editors menu, select File -> Open 
   From the file dialog, select: 
    $(_WINCEROOT)\Public\PenMount\PMSerialStylus\tchmdd.cec 
   and click Open.
   From CEC Editors menu, select Catalog -> "Add to Catalog"

4. Return Platform Builder and right-click on the Catalog and select 
   "Refresh Catalog". 
   
5. Locate "Third Party\Device Drivers\Touch\PenMount Serial Stylus". Then 
   right-click and select 'Add to OS Design'.

6. Please edit tchmdd.reg for hardware configuration like "Port"(for com port
   number), "Baudrate",and "Protocol"(choose control board). For example:
   
   "Port"=dword:1             ; the com-port number you are used to connect 
                              ; to PenMount controller.

   "Protocol"=dword:1         ; for PM9000
   "Protocol"=dword:3         ; for PM6000R (Serial)

   "Baudrate"=dword:2580      ; 9600
   "Baudrate"=dword:4B00      ; 19200


7. Build OS/Sysgen and Make Run-Time Image

8. [NOTE] When you got error after 7-step. Please execute prelink.bat in
   $(_WINCEROOT)\Public\PenMount\PMSerialStylus\ . And do "Make Run-Time Image" 
   from menu.

