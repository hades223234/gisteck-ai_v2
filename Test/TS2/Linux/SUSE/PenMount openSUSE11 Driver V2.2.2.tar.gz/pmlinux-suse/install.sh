#!/bin/bash

sudo -u root rm -rf /usr/share/penmount
sudo -u root rm -f /usr/share/applications/penmount.desktop
sudo -u root rm -f /usr/share/applications/penmount0.desktop
sudo -u root rm -f /usr/share/applications/penmount4.desktop
sudo -u root rm -f /usr/share/applications/penmount9.desktop
sudo -u root rm -f /usr/share/applications/penmount16.desktop
sudo -u root rm -f /usr/share/applications/penmount25.desktop

sudo -u root rm -f /usr/sbin/pm-calib
sudo -u root rm -f /usr/sbin/pm-sniff
sudo -u root rm -f /usr/sbin/pm-sniff-usb
sudo -u root rm -f /usr/sbin/gCalib
sudo -u root rm -f /etc/rc2.d/S08pm-setup
sudo -u root rm -f /etc/rc3.d/S08pm-setup
sudo -u root rm -f /etc/rc4.d/S08pm-setup
sudo -u root rm -f /etc/rc5.d/S08pm-setup


sudo -u root mkdir /usr/share/penmount
sudo -u root chown -R root.root *

sudo -u root cp -f penmount.png     /usr/share/penmount
sudo -u root cp -f pm-setup         /usr/sbin
sudo -u root cp -f penmount.dat     /etc
sudo -u root cp -f gCalib           /usr/sbin
sudo -u root cp -f penmount.desktop /usr/share/applications

#sudo -u root cp -f pm-sniff         /usr/sbin
#sudo -u root cp -f pm-sniff-usb     /usr/sbin
#sudo -u root cp -f pm-report        /usr/share/penmount
sudo -u root cp -f README-ubuntu804 /usr/share/penmount/README-ubuntu804

sudo -u root /usr/sbin/pm-setup
sudo -u root cp -f penmount_drv.so  /usr/lib/xorg/modules/input

