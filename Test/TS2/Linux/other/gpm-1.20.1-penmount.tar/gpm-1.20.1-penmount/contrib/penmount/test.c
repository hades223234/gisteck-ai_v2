
#include <asm/types.h>
#include <linux/input.h>
#include <stdio.h>

#include <ncurses.h>

#include <sys/time.h>

int main(int ac, char **av)
{

	struct input_event *e;
	int		f;
	char	s[64];
	unsigned char ebuf[256];
	int len;
	int maxx, maxy;
	int xcnt, ycnt, lcnt, ecnt, pcnt;
	int x, y;
	unsigned char flag;
        struct timeval tv;

	flag = 0;

	xcnt = ycnt = lcnt = ecnt = pcnt = 0;


	if (ac != 2) {
		fprintf(stderr, "test <arg>\n");
		return 0;
	}
	sprintf(s, "/dev/input/event%c", av[1][0]);

	printf("open %s\n", s);


	f = open(s, "r");
	if (!f) {
		fprintf(stderr, "open %s error!\n", s);
		return -1;
	}

//	initscr();
	//keypad(stdscr, TRUE);
	//nonl();
//	cbreak();
//	noecho();
//	maxx = getmaxx(stdscr);
//	maxy = getmaxy(stdscr);

	while (1) {
	len = read(f, ebuf, 256);


	for (e = (struct input_event *)ebuf;
		 e < (struct input_event *)(ebuf + len); e++) {
		if (e->type == EV_ABS) {
			if (e->code == ABS_X) {
				x = e->value;
				flag |= 0x01;
				xcnt++;
				//fprintf(stderr, "x = %d, ", e->value);
				//mvprintw(maxy-1, 20, "X:%d", ++xcnt);
			} else if (e->code == ABS_Y) {
				y = e->value;
				flag |= 0x02;
				ycnt++;
				//fprintf(stderr, "y = %d\n", e->value);
				//mvprintw(maxy-1, 30, "Y:%d", ++ycnt);
			}
			if ((flag & 0x03) == 3) {
				flag = 0;
				//mvprintw(maxy-1, 1, "(%4d,%4d)", x, y);
				fprintf(stderr, "(%4d,%4d)  X:%5d  Y:%5d L:    E:  \n", 
					x, y, xcnt, ycnt);
			}
			//mvprintw(maxy-1, 10, "    ");
		} else if (e->type == EV_KEY) {
			if (e->code == BTN_LEFT) {
				//fprintf(stderr, "left key\n");
				//mvprintw(maxy-1, 40, "L:%d",++lcnt);
				//mvprintw(maxy-1, 10, "LEFT");
				lcnt++;
				fprintf(stderr, "(    ,    )  X:       Y:      L:%3d E:%2d\n", lcnt, ecnt);
                                gettimeofday(&tv, (struct timezone *) NULL);
                                fprintf(stderr, "---> %d  %d\n", tv.tv_sec, tv.tv_usec);
			} else {
				//fprintf(stderr, "?? key\n");
				//mvprintw(maxy-1, 50, "E:%d",++ecnt);
				ecnt++;
            }
		}
	}


	}//while
//	endwin();

	return 0;
}
