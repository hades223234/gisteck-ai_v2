#   Copyright (c) By Dialogue Technology Corp. All rights reserved.
#   07/02/2009
#############################################################################

PenMount Serial Driver Package for Windows CE.Net 5.0

1. Copy Penmount to $(_WINCEROOT)\Public

2. Run Platform Builder. From menu, select Tools -> CEC Editors

3. From CEC Editors menu, select File -> Open 
   From the file dialog, select $(_WINCEROOT)\Public\PenMount\PMSerial\PM2Ser.cec 
   and click Open.
   From CEC Editors menu, select Catalog -> Add to Catalog

4. Return Platform Builder and right-click on the Catalog and select 
   "Refresh Catalog". 
   
5. Locate "Third Party\Device Drivers\Touch\PenMount Serial". Then 
   right-click and select 'Add to OS Design'.

6. Please edit PMSer.reg for hardware configuration like "Port"(for com port
   number), "Baudrate",and "Protocol"(choose control board). For example:
   
   "Port"=dword:1             ; the com-port number you are used to connect 
                              ; to PenMount controller.

   "Protocol"=dword:1         ; for PM9000
   "Protocol"=dword:3         ; for PM6000R (Serial)

   "Baudrate"=dword:2580      ; 9600
   "Baudrate"=dword:4B00      ; 19200

   "DisableEEPROM" = dword: 1 ; disable storing calibrate data to EEPROM 
                              ; of controller.
   
   [HKEY_LOCAL_MACHINE\Software\PenMount\Calibrate]
   "NoCal16"=dword:0        ; "NoCal16" - remove 16-point calibrate option from UI.
   "DefaultCalib"=dword:9   ; "DefaultCalib" - setting defualt calibrate algorithm.
                            ; 0 --> Standard Calibrate
                            ; 4 --> Advanced  4-Points Calibrate
                            ; 9 --> Advanced  9-Points Calibrate
                            ; 10--> Advanced 16-Points Calibrate

7. Build OS/Sysgen and Make Run-Time Image

8. [NOTE] When you got error after 7-step. Please execute prelink.bat in
   $(_WINCEROOT)\Public\PenMount\PMSerial\ . And do "Make Run-Time Image" from 
   menu.

