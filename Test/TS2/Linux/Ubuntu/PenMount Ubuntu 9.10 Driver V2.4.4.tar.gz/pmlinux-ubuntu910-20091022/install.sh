#!/bin/bash

filetime="$(date +%m%d%H%M%S)"

ls /etc/X11/xorg.conf
if [ $? != 0 ]; then
    sudo /usr/bin/Xorg -configure
    if [ $? != 0 ]; then
        sudo /etc/init.d/gdm stop
    else
        sudo mv ~/xorg.conf.new /etc/X11/xorg.conf
    fi
else
    sudo cp /etc/X11/xorg.conf /etc/X11/xorg.conf.$filetime
fi

sudo mkdir /usr/share/penmount
sudo chown -R root.root *
sudo cp -f penmount.png     /usr/share/penmount
sudo cp -f README-ubuntu904 /usr/share/penmount

sudo cp -f penmount.dat     /etc
sudo cp -f pm-setup         /usr/sbin
sudo cp -f gCal             /usr/sbin
sudo cp -f gDraw            /usr/sbin
sudo cp -f gPen             /usr/sbin
sudo cp -f penmount48.png   /usr/share/pixmaps/penmount.png
sudo cp -f penmount48.png   /usr/share/icons/gnome/48x48/apps/penmount.png
sudo cp -f penmount32.png   /usr/share/icons/gnome/32x32/apps/penmount.png
sudo cp -f penmount24.png   /usr/share/icons/gnome/24x24/apps/penmount.png
sudo cp -f penmount22.png   /usr/share/icons/gnome/22x22/apps/penmount.png
sudo cp -f penmount16.png   /usr/share/icons/gnome/16x16/apps/penmount.png
sudo cp -f penmount.desktop /usr/share/applications
mkdir ~/.config
mkdir ~/.config/autostart
cp -f penmount_autostart.desktop ~/.config/autostart/penmount.desktop


sudo /usr/sbin/pm-setup -s
sudo cp -f penmount_drv.so  /usr/lib/xorg/modules/input
sudo cp -f kbd_drv.so       /usr/lib/xorg/modules/input
sudo cp -f mouse_drv.so     /usr/lib/xorg/modules/input

sudo /etc/init.d/gdm start
