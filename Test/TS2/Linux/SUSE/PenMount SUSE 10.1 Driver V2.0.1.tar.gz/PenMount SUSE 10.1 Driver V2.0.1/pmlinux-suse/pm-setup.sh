#!/bin/bash

/usr/sbin/pm-setup -s

modprobe pcspkr
